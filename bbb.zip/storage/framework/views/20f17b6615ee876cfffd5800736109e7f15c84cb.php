<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <link rel="stylesheet" href="<?php echo e(asset('css/master.css')); ?>">
        <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('vendor/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    </head>
    <body>

        <!-- Menubar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-dark" id="id_1">
            <a id="logo_main" class="navbar-brand" href="#">FoodBook</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav" id="navbar_link">
                    <a class="nav-item nav-link li_space font-weight-light" <?php echo $__env->yieldContent('findfood'); ?> href="<?php echo e(route('findfood')); ?>">Find Food</a>
                    <a class="nav-item nav-link li_space font-weight-light" <?php echo $__env->yieldContent('findRestaurant'); ?> href="<?php echo e(route('findRestaurant_public')); ?>">Find Restaurant</a>
                </div>

                <div class="btn-group" id="login_reg_btn">
                    <a class="btn btn-outline-info" href="<?php echo e(route('showRegistration')); ?>">Register</a>
                    <a class="btn btn-outline-info" href="<?php echo e(route('showLogin')); ?>">Login</a>
                  </div>
                </div>

            </div>
        </nav>

        <!-- Page Content -->
        <div class="container-fluid">
            <div class="col-lg-12">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
        <!-- /.container -->


    <div class="footer">
        <p id="myfooter">© 2018 Copyright: arabikabir.com</p>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('js/sb-admin.min.js')); ?> "></script>

    </body>
</html>
