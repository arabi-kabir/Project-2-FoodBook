

<?php $__env->startSection('ManagePage'); ?>
    id="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('createPage'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card bg-light" id="page-list-table">
      <div class="card-header">
        Create Page
      </div>
      <div class="card-body">
          <?php echo $__env->make('Include.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <form method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="user_id" value="<?php echo e(session('user')->id); ?>">
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Page Name</label>
              <div class="col-sm-10">
                <input type="text" name="page_name" class="form-control" placeholder="Page Name">
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Page Picture</label>
              <div class="col-sm-10">
                <input type="file" name="page_pic" class="form-control">
              </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Area</label>
                <div class="col-sm-10">
                    <select class="form-control" name="area">
                      <?php $__currentLoopData = $arealist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($area->area_name); ?>"><?php echo e($area->area_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
              </div>
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Address</label>
              <div class="col-sm-10">
                <textarea name="address" class="form-control" rows="3" placeholder="Address"></textarea>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-2 col-form-label"></label>
              <div class="col-sm-10">
                <button type="submit" class="btn btn-primary">Create Page</button>
              </div>
            </div>
          </form>
      </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.ManagePage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>