<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <link rel="stylesheet" href="<?php echo e(asset('css/master.css')); ?>">
        <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('vendor/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    </head>
    <body>

        <!-- Menubar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-dark" id="id_1">
            <a id="logo_main" class="navbar-brand" href="#">FoodBook</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav" id="navbar_link">
                    <a class="nav-item nav-link li_space font-weight-light" <?php echo $__env->yieldContent('Home'); ?> href="<?php echo e(route('timeline')); ?>">Home</a>
                    <a class="nav-item nav-link li_space font-weight-light" <?php echo $__env->yieldContent('Profile'); ?> href="<?php echo e(route('profileIndexPage')); ?>">Profile</a>
                    <a class="nav-item nav-link li_space font-weight-light" <?php echo $__env->yieldContent('ManegaPage'); ?> href="<?php echo e(route('showPagelist')); ?>">Manage Page</a>
                </div>

                <div class="btn-group" id="login_reg_btn">
                  <button id="logoutBtn-2" type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <img id="pro_pic_top" src="/upload/profile_picture/<?php echo e(session('user')->profilePicture); ?>" alt="Not Found"> <?php echo e(session('user')->fullname); ?>

                  </button>
                  <div class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="">Profile</a>
                    <a class="dropdown-item" href="">Accounts</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a>
                  </div>
                </div>

            </div>
        </nav>

        <!-- Page Content -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-2">

                    <img id="pro_pic" src="/upload/profile_picture/<?php echo e(session('user')->profilePicture); ?>" alt="Not Found">
                    <div class="" id="user_name_head">
                        <h4 class="font-weight-light"> <span class="badge badge-secondary font-weight-light">User - <?php echo e(session('user')->fullname); ?></span> </h4>
                    </div>
                    <div class="list-group">
                        <a href="" class="list-group-item <?php echo $__env->yieldContent('timeline'); ?>">
                            <i class="fa fa-fw fa-home"></i>
                            Timeline
                        </a>
                        <a href="" class="list-group-item <?php echo $__env->yieldContent('searchFood'); ?>">
                            <i class="fa fa-fw fa-search"></i>
                            Search Food
                        </a>
                        <a href="" class="list-group-item <?php echo $__env->yieldContent('followers'); ?>">
                            <i class="fa fa-fw fa-star-half-o"></i>
                            Followers
                        </a>
                        <a href="" class="list-group-item <?php echo $__env->yieldContent('followList'); ?>">
                            <i class="fa fa-fw fa-address-card"></i>
                            Follow List
                        </a>
                        <a href="" class="list-group-item <?php echo $__env->yieldContent('messges'); ?>">
                            <i class="fa fa-fw fa-envelope"></i>
                            Messges
                        </a>

                    </div>
                </div>
                <!-- /.col-lg-3 -->

                <div class="col-lg-10">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->


    <div class="footer">
        <p id="footerPadding">© 2018 Copyright: arabikabir.com</p>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('js/sb-admin.min.js')); ?> "></script>

    </body>
</html>
