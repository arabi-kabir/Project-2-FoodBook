

<?php $__env->startSection('ManagePage'); ?>
    id="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageList'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card bg-light" id="page-list-table">
      <div class="card-header">
        Page List
      </div>
      <div class="card-body">
          <?php echo $__env->make('Include.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <table class="table table-bordered table-hover" id="page-list-table-core">
              <thead>
                  <tr>
                    <th scope="col" class="make_text_center">#</th>
                    <th scope="col" class="make_text_center">Page Name</th>
                    <th scope="col" class="make_text_center">Page Status</th>
                    <th scope="col" class="make_text_center">Action</th>
                  </tr>
              </thead>
              <tbody>
                  <?php $__currentLoopData = $pagelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row" class="make_text_center"><?php echo e(++$key); ?></th>
                    <td class="make_text_center"><?php echo e($page->page_name); ?></td>
                    <td class="make_text_center"><?php echo e($page->status); ?></td>
                    <td class="make_text_center"> <a class="btn btn-info" href="<?php echo e(route('myPost', ['id' => $page->id])); ?>">Open Page</a> </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>
      </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.ManagePage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>