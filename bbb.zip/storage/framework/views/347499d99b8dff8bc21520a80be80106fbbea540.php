<?php $__env->startSection('Home'); ?>
    id="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('searchFood'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="err-msg">
        <?php echo $__env->make('Include.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <div class="card bg-light" id="page-list-table">
      <div class="card-header" id="food-action-byn-group">
        Item Name - <?php echo e($food->foodName); ?>


      </div>
      <div class="card-body row less-padd">
          <table class="table">
            <tbody>
                <tr>
                  <th scope="col">Iten Name</th>
                  <td scope="col"><?php echo e($food->foodName); ?></td>
                  <td rowspan="4"><img class="card-img-top" id="food_img" src="/upload/food_picture/<?php echo e($food->food_img); ?>" alt="Card image cap"></td>
                </tr>
                <tr>
                  <th scope="col">Category</th>
                  <td scope="col"><?php echo e($food->category); ?></td>
                </tr>
                <tr>
                  <th scope="col">Price</th>
                  <td scope="col"><?php echo e($food->Price); ?></td>
                </tr>
                <tr>
                  <th scope="col">Rating</th>
                  <td scope="col"><?php echo e($food->rating); ?></td>
                </tr>
                <tr>
                  <th scope="col">Description</th>
                  <td scope="col"><?php echo e($food->food_discription); ?></td>
                </tr>
                <tr>
                  <th scope="col">Availability</th>
                  <td scope="col"><?php echo e($food->availability); ?></td>
                </tr>
              </tbody>
         </table>
      </div>
    </div>

    <div id="review">
        <form method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="food_id" value="<?php echo e($food->id); ?>">
            <div class="form-group">
                <label id="post-head-2">Write a review</label>
                <textarea required name="review" class="form-control" rows="3" placeholder="Put your review here . . ."></textarea>
            </div>
            <button type="submit" class="btn btn-success float-right">Submit</button>
        </form>
    </div>

    <h2 class="font-weight-light">Reviews</h2>
    <br>
    <table class="table table-bordered">
      <tbody>
        <?php $__currentLoopData = $foodReview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td> <span class="badge badge-primary"><?php echo e($review->reviewer_name); ?></span>  <?php echo e($review->review); ?> <p class="badge badge-info">Date : <?php echo e($review->date); ?></p> </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.Timeline', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>