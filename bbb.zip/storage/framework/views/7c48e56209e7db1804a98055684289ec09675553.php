

<?php $__env->startSection('title'); ?>
    FoodBook
<?php $__env->stopSection(); ?>

<?php $__env->startSection('findRestaurant'); ?>
    id="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('search_page_keyword_public')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="form-group col-10 margin-1">
              <input type="text" name="foodname" class="form-control" placeholder="Restaurant or Area">
            </div>
            <div class="form-group col-2">
                <button type="submit" class="btn btn-success btn-block margin-1">Search</button>
            </div>
        </div>
    </form>
    <!-- food list -->
    <div class="card-body row less-padd">
       <table class="table  table-hover">
          <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Page Cover</th>
                <th scope="col">Page Name</th>
                <th scope="col">Area</th>
                <th scope="col">Open Page</th>
              </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $pagelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <th scope="row"><?php echo e(++$key); ?></th>
                  <td><img class="card-img-top" id="page_img-sm" src="/upload/page_picture/<?php echo e($page->page_pic); ?>" alt="Card image cap"></td>
                  <td><?php echo e($page->page_name); ?></td>
                  <td><?php echo e($page->area); ?></td>
                  <td class="ui-helper-center">  <a href="<?php echo e(route('viewfoodpage_public', ['page_id' => $page->id])); ?>" class="card-link btn btn-outline-secondary btn-sm">View Page</a> </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.publicView', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>