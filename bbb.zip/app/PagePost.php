<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PagePost extends Model
{
    //
}
