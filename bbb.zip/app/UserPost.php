<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserPost extends Model
{
    //
}
