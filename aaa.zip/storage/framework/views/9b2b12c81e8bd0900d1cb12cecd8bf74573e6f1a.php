<?php $__env->startSection('Home'); ?>
    id="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('searchFood'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="">
        <div id="err-msg">
            <?php echo $__env->make('Include.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <div class="card bg-light" id="page-list-table">

          <div class="card-header">
            <h4 id="user-name-head">Page - <?php echo e($page->page_name); ?></h4>
            <h5 id="user-name-head">Address - <?php echo e($page->address); ?></h5>
          </div>
          <div class="card-body row less-padd">
              <?php $__currentLoopData = $foodlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="card col-3 no-padding" style="width: 20rem;">
                    <img class="card-img-top" id="food_img" src="/upload/food_picture/<?php echo e($food->food_img); ?>" alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title"><?php echo e($food->foodName); ?></h5>
                    </div>
                    <ul class="list-group list-group-flush">
                      <li class="list-group-item">Category : <?php echo e($food->category); ?></li>
                      <li class="list-group-item">Price : <?php echo e($food->Price); ?></li>
                    </ul>
                    <div class="card-body">
                      <a href="<?php echo e(route('viewsinglefood', ['food_id' => $food->id])); ?>" class="card-link btn btn-outline-info btn-sm">View Item</a>
                    </div>
                  </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.Timeline', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>