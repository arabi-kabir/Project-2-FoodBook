<?php $__env->startSection('Profile'); ?>
    id="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('followlist'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="follow-list-full-page" class="row">
        <div id="serachUser" class="col-6">
            <form class="row" id="searchuser_searchbar" action="" method="post">
                <div class="form-group col-3">
                    <select class="form-control" name="cat_name">
                        <option value="user">User</option>
                        <option value="page">Page</option>
                    </select>
                </div>
                <div class="form-group col-6">
                  <input type="text" name="username" class="form-control" placeholder="Search user">
                </div>
                <div class="col-3">
                    <button type="submit" class="btn btn-outline-info btn-block">Search</button>
                </div>
            </form>

            <!--user card-->
            <?php $__currentLoopData = $userlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card text-center" id="single-user-minicard" style="width: 100%;">
              <div class="card-body row less-padding">
                <div id="user-img" class="col-4">
                    <img class="img-thumbnail" id="profile-pic-followlist" src="/upload/profile_picture/<?php echo e($user->profilePicture); ?>" alt="">
                </div>
                <div id="user-info" class="col-8">
                     <table class="table table-sm table-bordered">
                         <tbody>
                            <tr>
                              <td>Name</td>
                              <td><?php echo e($user->fullname); ?></td>
                            </tr>
                            <tr>
                              <td>E-mail</td>
                              <td><?php echo e($user->email); ?></td>
                            </tr>
                            <tr>
                              <td>Area</td>
                              <td><?php echo e($user->area); ?></td>
                            </tr>
                          </tbody>
                     </table>
                </div>
              </div>
              <div class="card-footer">
                  <form action="<?php echo e(route('follow_this_guy')); ?>" method="post">
                      <input type="hidden" name="userid" value="<?php echo e(session('user')->id); ?>">
                      <input type="hidden" name="follow_userid" value="<?php echo e($user->id); ?>">
                      <button type="submit" class="btn btn-outline-success btn-sm float-left" id="">Follow</button>
                  </form>

                <a href="#" class="btn btn-outline-primary btn-sm float-right">View Profile</a>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!--followlist table-->
        <div id="followerlist-table" class="col-6">

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.Profile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>