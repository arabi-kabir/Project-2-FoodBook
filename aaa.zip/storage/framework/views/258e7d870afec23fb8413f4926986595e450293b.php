<div class="col-12">
    <br>
    <h2 class="font-weight-light">Comments</h2>
    <table class="table table-bordered">
      <tbody>
        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                  <h5 class="">[<?php echo e($comment->user_name); ?>]</h5>
                  <h6>[ <?php echo e($comment->date); ?> ]</h6>
                  <p><?php echo e($comment->comment); ?></p>
              </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
</div>
