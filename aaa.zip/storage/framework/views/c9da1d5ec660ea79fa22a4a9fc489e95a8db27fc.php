

<?php $__env->startSection('Home'); ?>
    id="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('timeline'); ?>
    id="active"
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="row">
    	<div class="col-sm-8" style="overflow-y: scroll; height:100vh;">
         
	         <?php echo $__env->make('Home.layouts.myPost', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	    	 <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    	    <br>
		        <?php if($post->page_user == 'page' and $post->type == 'newfood'): ?>   
		           <?php echo $__env->make('Home.layouts.foodItem', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		        
		        <?php elseif($post->page_user == 'page' and $post->type == 'pagepost'): ?>
	               <?php echo $__env->make('Home.layouts.pagePost', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	            <?php elseif($post->page_user == 'user' and $post->type == 'userpost'): ?>
	               <?php echo $__env->make('Home.layouts.userPost', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 
		        <?php endif; ?>
	         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	         <br>
	         <br>
             
             <?php if($posts->hasMorePages()): ?>
		         <div class="col-sm-12">
		         	 <h4 style="margin: 0 auto;width:20%;"><a href="<?php echo e($posts->nextPageUrl()); ?>" class="card-link btn btn-outline-info btn-sm">More</a></h4>
		         </div>
		     <?php else: ?>
		         <div class="col-sm-12">
		         	 <h4 style="margin: 0 auto;width:20%;"><a href="<?php echo e($posts->previousPageUrl()); ?>" class="card-link btn btn-outline-info btn-sm">Previous</a></h4>
		         </div>

		     <?php endif; ?>
	        
    	</div>
    	
    	<div class="col-sm-4">
    	  <br>
          <ul class="list-group">
           <li class="list-group-item">People you may know</li>
    	   <?php $__currentLoopData = $peoples; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $people): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php if(! App\follow_list::isFollowed($people->id,'user')): ?>
    		    <?php echo $__env->make('Home.layouts.peopleYouMayKnow', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    		 <?php endif; ?>
    	   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	  </ul>
    	</div>
    </div>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.Timeline', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>