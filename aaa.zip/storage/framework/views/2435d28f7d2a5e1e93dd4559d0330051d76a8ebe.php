<?php $__env->startSection('ManagePage'); ?>
    id="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addCategory'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="">
        <div id="err-msg">
            <?php echo $__env->make('Include.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <div class="card bg-light" id="page-list-table">

          <div class="card-header">
            Add Category
          </div>
          <div class="card-body">
              <form method="post" action="<?php echo e(route('insertCategory')); ?>" enctype="multipart/form-data">
                <input type="hidden" name="page_id" value="<?php echo e($page->id); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                  <label class="col-sm-2 col-form-label">Category Name</label>
                  <div class="col-sm-10">
                    <input type="text" required name="cat_name" class="form-control" placeholder="Category Name">
                  </div>
                </div>
                <div class="form-group row">
                  <label class="col-sm-2 col-form-label"></label>
                  <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Create</button>
                  </div>
                </div>
              </form>
          </div>
        </div>

        <!-- Category List -->
        <table class="table table-bordered table-sm table-hover" id="cat-table">
            <thead>
                <tr>
                  <th scope="col" class="make_text_center table-dark">#</th>
                  <th scope="col" class="make_text_center table-dark">Category Name</th>
                  <th scope="col" class="make_text_center table-dark">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row" class="make_text_center"><?php echo e(++$key); ?></th>
                  <td class="make_text_center"><?php echo e($cat->category); ?></td>
                  <td class="make_text_center"> <button type="button" class="btn btn-sm btn-outline-danger" data-toggle="modal" data-target="#exampleModal<?php echo e($key); ?>" data-whatever="@getbootstrap">Delete Category</button> </td>
                </tr>

                <!-- Delete Post Modal -->
                <div class="modal fade" id="exampleModal<?php echo e($key); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Are you sure want to Delete ?</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <form method="post" action="<?php echo e(route('deleteCategory')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="page_id" value="<?php echo e($page->id); ?>">
                            <input type="hidden" name="cat_id" value="<?php echo e($cat->id); ?>">
                            <h4>Category Name - <?php echo e($cat->category); ?></h4>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary">Delete</button>
                            </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>




    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.Page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>