<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title></title>
        <link rel="stylesheet" href="<?php echo e(asset('asset/css')); ?>">

        <link href="<?php echo e(asset('asset/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    	<link href="<?php echo e(asset('asset/css/paper-kit.css')); ?>" rel="stylesheet"/>
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    </head>
    <body>

        hi bro

    </body>

    <script src="<?php echo e(asset('asset/js/jquery-3.2.1.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('asset/js/jquery-ui-1.12.1.custom.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('asset/js/bootstrap.min.js')); ?>" type="text/javascript"></script>

</html>
