<?php $__env->startSection('ManagePage'); ?>
    id="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mypost'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="" id="full-mypost-page">
        <form method="post" enctype="multipart/form-data" id="post-full-form">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="page_id" value="<?php echo e($page->id); ?>">
            <div class="row" id="margin-1">
                <div class="form-group col-9">
                    <label id="post-head">Put Your Thoughts Here</label>

                    <div class="form-group">
                        <input type="text" name="title" class="form-control" placeholder="Title">
                    </div>
                    <textarea name="post_data" class="form-control" rows="3" placeholder="Your Post"></textarea>
                </div>
                <div class="form-group col-3" id="post-image">
                    <input type="file" name="img1" class="form-control post-img" >
                    <input type="file" name="img2" class="form-control post-img" >
                    <input type="file" name="img3" class="form-control post-img" >
                </div>
            </div>
            <button type="submit" class="btn btn-outline-primary">Submit</button>
        </form>
        <div id="err-msg">
            <?php echo $__env->make('Include.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <div class="row" id="post-list">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12">
                    <div class="card bg-light" id="page-list-table">
                      <div class="card-header">
                        <?php echo e($post->title); ?>

                        <a href="<?php echo e(route('viewpost', ['id' => $post->id, 'page_id' => $page->id])); ?>" class="btn btn-outline-info btn-sm float-right">View</a>
                      </div>
                      <div class="card-body">
                          <div class="row">
                              <div class="col-8">
                                  <p><?php echo e($post->post); ?></p>
                              </div>
                              <div class="col-4">
                                  <img class="img-thumbnail float-right" src="/upload/page_post_picture/<?php echo e($post->img1); ?>" id="post-img-view" alt="">
                              </div>
                          </div>
                      </div>
                      <div class="card-footer text-muted">
                        <?php echo e($post->date); ?>

                        <?php
                            $k = 0
                        ?>

                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($post->id == $comment->post_id): ?>
                                <?php echo e($k++); ?>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <span class="float-right badge badge-info vote-space"> <p class="vote-text-space">Comments : <?php echo e($k); ?> </p> </span>
                        <span class="float-right badge badge-success vote-space"> <p class="vote-text-space">Upvote : <?php echo e($post->upvote); ?></p> </span>
                        <span class="float-right badge badge-danger vote-space"> <p class="vote-text-space">Downvote : <?php echo e($post->downvote); ?></p></span>
                      </div>
                    </div>
                    <form class="container-fluid" action="<?php echo e(route('addComment_Pagepost')); ?>" method="post">
                        <input type="hidden" name="page_id" value="<?php echo e($post->page_id); ?>">
                        <?php echo $__env->make('Layouts.Comment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </form>
                </div>
                <div class="col">

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.Page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>