<?php $__env->startSection('Home'); ?>
    id="active"
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.Timeline', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>